# Systemic Tau and RECD

Python implementation of the Systemic Tau paradigm and the Discrete Extramental Clock (RECD).

This package implements:
- Ordinal Systemic Tau computation (`core.py`)
- RECD increment and gated accumulation logic (`recd.py`)
- The Three-Layer Ontology: local intensification, relational coherence, and structural reorganization (`layers.py`)
- Fractal dimension estimation of generated extramental time (`fractal.py`)

# Systemic Tau and RECD

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.20902148.svg)](https://doi.org/10.5281/zenodo.20902148)
[![PyPI version](https://badge.fury.io/py/systemictau.svg)](https://badge.fury.io/py/systemictau)
[![Python](https://img.shields.io/badge/Python-3.9%2B-blue)](https://www.python.org/)

Python implementation of the **Systemic Tau** paradigm and the **Discrete Extramental Clock (RECD)**.

## Descripción

Este paquete implementa el núcleo del paradigma del Tau Sistémico desarrollado por Johel Padilla-Villanueva:

- Cálculo de **Systemic Tau** (coherencia ordinal global y por módulo)
- **RECD** – Reloj Extramental Discreto (acumulación gobernada por constante de Feigenbaum)
- Ontología de **tres capas** (hiper-persistencia, episodios conjuntos y reorganización estructural)
- Estimación de dimensión fractal Higuchi del tiempo extramental acumulado

## Instalación

```bash
pip install systemictau
Uso básico
Pythonimport systemictau as st
import numpy as np

# Ejemplo con mapas logísticos acoplados
# (ver example_logistic.py para más detalle)

# X: matriz multivariada (tiempo x componentes)
taus_global, taus_per_module = st.compute_taus(X, window_size=13)

# Acumulación RECD
T_series, dtk, gate, depths = st.accumulate_time(taus_global)

# Detección de episodios conjuntos (Capa 2)
hp_z, core_hyper = st.hyper_persistence(taus_global)
# ... (ver documentación completa)
Cita / Citation
bibtex@software{padilla_villanueva_systemictau_2026,
  author       = {Padilla-Villanueva, Johel},
  title        = {systemictau: Systemic Tau and RECD implementation},
  year         = 2026,
  publisher    = {Zenodo},
  doi          = {10.5281/zenodo.20902148},
  url          = {https://doi.org/10.5281/zenodo.20902148}
}
Enlaces importantes

DOI: 10.5281/zenodo.20902148
PyPI: https://pypi.org/project/systemictau/
Documentación y ejemplos: Próximamente
Preprints relacionados: Ver Zenodo y Preprints.org

Licencia
MIT License (ver archivo LICENSE).