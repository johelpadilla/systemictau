# Ref: Dual Plots Improved (Prompt A1 Refinements) — 2026-07-02

**Date**: 2026-07-02  
**Tag**: ref/dual-plots-improved-2026-07-02  
**Base commit**: c181286 + subsequent refinements on dev/next

## What this preserves

This is the **improved, publication-grade state** of the dual-plot function (`plot_scale_detail`) after applying the detailed requirements from Prompt A1.

### Key improvements over the previous "good-visuals" reference:

- **GridSpec height_ratios**: (1.0, 1.42) — bottom Δt_k panel now has meaningful vertical weight.
- **Bottom panel (Δt_k)**: Strong visual presence
  - vlines with `linewidth=2.10`
  - Scatter markers at the top of each spike
  - Subtle area fill underneath for visual mass
- **Visual integration**:
  - Light vertical shaded band (`TSTAR_BAND_COLOR`) drawn across **both** top and bottom panels at exact t* location.
- **t* markers**:
  - Identical prominent styling (line + triangle marker + label) on top and bottom.
  - Robust positioning on top panel using actual data range + headroom.
  - Bottom panel label placed safely above the spike using real max + headroom.
- **Final RECD annotation**: Clean rounded bbox with matching red color + `.4f` precision + end-of-curve marker.
- **Centralized constants**: All colors, linewidths, alphas, band style, etc. defined at module level for maintainability.
- **Consistency**: Local / Medium / Global use exactly the same treatment.
- **Overall**: The two panels now feel like one cohesive, high-quality figure (no longer "two loosely connected panels").

## Contents

- `viz.py` — the exact improved visualization module
- `report_dual_plots_refined.pdf` — full multi-perspective report generated with the improved dual plots
- `dev_real_*_final.png` — dual plots (Local/Medium/Global) generated with real analysis on Aedes_Mock_Panel.csv
- `dev_dual_*_refined.png` — additional dual plot examples
- `dual-plots-improved.bundle` — git bundle containing the exact ref (can be cloned directly)

## How to use this reference

### Option A — Use the files directly (recommended)
Just copy this whole folder. All plots and the report are ready to inspect or include in papers.

### Option B — Restore the code via git tag
```bash
git checkout ref/dual-plots-improved-2026-07-02
```

### Option C — Use the bundle (portable)
```bash
git clone ref-2026-07-02-dual-plots-improved/dual-plots-improved.bundle my-restored-version
cd my-restored-version
git checkout ref/dual-plots-improved-2026-07-02
```

## How to "upload" / backup this version (simple for non-git users)

1. Zip this entire folder:
   ```bash
   cd /Users/johelpadilla/Investigaciones/systemictau_v4/versions
   zip -r ref-2026-07-02-dual-plots-improved.zip ref-2026-07-02-dual-plots-improved/
   ```
2. Upload the `.zip` to:
   - Google Drive / Dropbox / iCloud
   - Attach to a GitHub issue or release as "asset"
   - Add as supplementary material in Zenodo / Overleaf / paper repo

This matches the exact preservation pattern used across your other projects (`versions/v0.1.x-...`).

## Notes for future work

- All new dual-plot or report work should be compared visually against the images in this folder.
- The improvements were applied using the centralized publication style constants defined in `viz.py`.
- Minor font warnings (DejaVu semibold fallback) are pre-existing and do not affect output quality.

**This is the current "known good" baseline for dual plots.**

## Quick commands (if you want to recreate similar artifacts)

```bash
cd /Users/johelpadilla/Investigaciones/systemictau_v4
python -c "
import pandas as pd, sys
sys.path.insert(0,'src')
from systemictau.studio.analysis import run_multi_ontological_analysis
from systemictau.studio.viz import plot_scale_detail, create_report_pdf

df = pd.read_csv('Aedes_Mock_Panel.csv')
an = run_multi_ontological_analysis(df, window_size=11)
for s in ['Local','Medium','Global']:
    plot_scale_detail(s, an['scale_results'][s]).savefig(f'dev_real_{s.lower()}_final.png', dpi=170)
create_report_pdf(an, raw_shape=df.shape, window_size=11, filename='report_dual_plots_refined.pdf')
"
```

---

Preserved by Grok on behalf of the user (who requested "hazlo mejor pero tú").
